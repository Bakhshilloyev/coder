/**
 * Progress Hook
 * Manages user learning progress and statistics
 */

import { useState, useEffect } from 'react';
import {
  getUserProfile,
  getCourses,
  getAchievements,
  updateStreak,
  initializeData,
  type UserProfile,
  type UserAchievement,
} from '../services/storageService';
import type { Course } from '../constants/courses';

export function useProgress() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [achievements, setAchievements] = useState<UserAchievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      await initializeData();
      await updateStreak();

      const [profileData, coursesData, achievementsData] = await Promise.all([
        getUserProfile(),
        getCourses(),
        getAchievements(),
      ]);

      setProfile(profileData);
      setCourses(coursesData);
      setAchievements(achievementsData);
    } catch (error) {
      console.error('Failed to load progress data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function refresh() {
    await loadData();
  }

  const stats = {
    totalCourses: courses.length,
    completedLessons: profile?.totalLessons || 0,
    totalMinutes: profile?.totalMinutes || 0,
    streak: profile?.streak || 0,
    level: profile?.level || 1,
    xp: profile?.xp || 0,
    unlockedAchievements: achievements.filter(a => a.unlocked).length,
  };

  return {
    profile,
    courses,
    achievements,
    stats,
    loading,
    refresh,
  };
}
