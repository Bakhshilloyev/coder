/**
 * Course Hook
 * Manages individual course data and lesson progress
 */

import { useState, useEffect } from 'react';
import { getCourses, completeLesson as completeLessonService } from '../services/storageService';
import type { Course, Lesson } from '../constants/courses';

export function useCourse(courseId: string) {
  const [course, setCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCourse();
  }, [courseId]);

  async function loadCourse() {
    try {
      const courses = await getCourses();
      const foundCourse = courses.find(c => c.id === courseId);
      if (foundCourse) {
        setCourse(foundCourse);
        // Set first incomplete lesson or first lesson
        const firstIncomplete = foundCourse.lessons.find(l => !l.completed);
        setCurrentLesson(firstIncomplete || foundCourse.lessons[0]);
      }
    } catch (error) {
      console.error('Failed to load course:', error);
    } finally {
      setLoading(false);
    }
  }

  async function completeLesson(lessonId: string) {
    if (!course) return;

    try {
      await completeLessonService(course.id, lessonId);
      await loadCourse();
    } catch (error) {
      console.error('Failed to complete lesson:', error);
    }
  }

  async function selectLesson(lessonId: string) {
    if (!course) return;
    const lesson = course.lessons.find(l => l.id === lessonId);
    if (lesson) {
      setCurrentLesson(lesson);
    }
  }

  const progress = course
    ? Math.round((course.completedLessons / course.totalLessons) * 100)
    : 0;

  return {
    course,
    currentLesson,
    loading,
    progress,
    completeLesson,
    selectLesson,
    refresh: loadCourse,
  };
}
