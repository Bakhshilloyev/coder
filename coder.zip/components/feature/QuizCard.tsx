import React, { useState } from 'react';
import { View, Text, StyleSheet, useColorScheme, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import type { Quiz } from '../../constants/courses';

interface QuizCardProps {
  quiz: Quiz;
  onComplete: (correct: boolean) => void;
}

export function QuizCard({ quiz, onComplete }: QuizCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const handleSubmit = () => {
    if (selectedAnswer === null) return;
    setSubmitted(true);
    const isCorrect = selectedAnswer === quiz.correctAnswer;
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  const isCorrect = submitted && selectedAnswer === quiz.correctAnswer;
  const isWrong = submitted && selectedAnswer !== quiz.correctAnswer;

  return (
    <Card variant="elevated">
      <View style={styles.header}>
        <Ionicons name="help-circle" size={24} color={Colors.primary.main} />
        <Text style={[styles.title, isDark && styles.titleDark]}>Viktorina</Text>
      </View>

      <Text style={[styles.question, isDark && styles.questionDark]}>{quiz.question}</Text>

      <View style={styles.options}>
        {quiz.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const isCorrectOption = submitted && index === quiz.correctAnswer;
          const isWrongOption = submitted && isSelected && index !== quiz.correctAnswer;

          return (
            <TouchableOpacity
              key={index}
              style={[
                styles.option,
                isDark ? styles.optionDark : styles.optionLight,
                isSelected && !submitted && styles.optionSelected,
                isCorrectOption && styles.optionCorrect,
                isWrongOption && styles.optionWrong,
              ]}
              onPress={() => !submitted && setSelectedAnswer(index)}
              disabled={submitted}
              activeOpacity={0.7}
            >
              <View style={styles.optionContent}>
                <View
                  style={[
                    styles.radio,
                    isSelected && styles.radioSelected,
                    isCorrectOption && styles.radioCorrect,
                    isWrongOption && styles.radioWrong,
                  ]}
                >
                  {(isSelected || isCorrectOption) && (
                    <View style={styles.radioDot} />
                  )}
                </View>
                <Text
                  style={[
                    styles.optionText,
                    isDark && styles.optionTextDark,
                    isCorrectOption && styles.optionTextCorrect,
                  ]}
                >
                  {option}
                </Text>
              </View>
              {isCorrectOption && (
                <Ionicons name="checkmark-circle" size={20} color={Colors.success} />
              )}
              {isWrongOption && (
                <Ionicons name="close-circle" size={20} color={Colors.error} />
              )}
            </TouchableOpacity>
          );
        })}
      </View>

      {!submitted && (
        <Button
          title="Javobni tekshirish"
          onPress={handleSubmit}
          disabled={selectedAnswer === null}
          fullWidth
        />
      )}

      {submitted && (
        <View style={[styles.result, isCorrect ? styles.resultCorrect : styles.resultWrong]}>
          <Ionicons
            name={isCorrect ? 'checkmark-circle' : 'close-circle'}
            size={24}
            color={isCorrect ? Colors.success : Colors.error}
          />
          <Text style={[styles.resultText, isCorrect ? styles.resultTextCorrect : styles.resultTextWrong]}>
            {isCorrect ? 'To\'g\'ri javob! 🎉' : 'Xato javob. Qaytadan urinib ko\'ring.'}
          </Text>
        </View>
      )}
    </Card>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: Typography.fontSize.lg,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  question: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.medium,
    color: Colors.light.text.primary,
    marginBottom: Spacing.lg,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
  },
  questionDark: {
    color: Colors.dark.text.primary,
  },
  options: {
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 2,
  },
  optionLight: {
    backgroundColor: Colors.light.surface,
    borderColor: Colors.light.border,
  },
  optionDark: {
    backgroundColor: Colors.dark.surface,
    borderColor: Colors.dark.border,
  },
  optionSelected: {
    borderColor: Colors.primary.main,
  },
  optionCorrect: {
    borderColor: Colors.success,
    backgroundColor: Colors.success + '10',
  },
  optionWrong: {
    borderColor: Colors.error,
    backgroundColor: Colors.error + '10',
  },
  optionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flex: 1,
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: BorderRadius.full,
    borderWidth: 2,
    borderColor: Colors.light.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioSelected: {
    borderColor: Colors.primary.main,
  },
  radioCorrect: {
    borderColor: Colors.success,
  },
  radioWrong: {
    borderColor: Colors.error,
  },
  radioDot: {
    width: 10,
    height: 10,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.primary.main,
  },
  optionText: {
    fontSize: Typography.fontSize.base,
    color: Colors.light.text.primary,
    flex: 1,
  },
  optionTextDark: {
    color: Colors.dark.text.primary,
  },
  optionTextCorrect: {
    fontWeight: Typography.fontWeight.semibold,
  },
  result: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  resultCorrect: {
    backgroundColor: Colors.success + '15',
  },
  resultWrong: {
    backgroundColor: Colors.error + '15',
  },
  resultText: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.medium,
    flex: 1,
  },
  resultTextCorrect: {
    color: Colors.success,
  },
  resultTextWrong: {
    color: Colors.error,
  },
});
