import React from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Card } from '../ui/Card';
import { ProgressBar } from '../ui/ProgressBar';
import { Badge } from '../ui/Badge';
import { Colors, Typography, Spacing } from '../../constants/theme';
import type { Course } from '../../constants/courses';

interface CourseCardProps {
  course: Course;
  onPress: () => void;
}

export function CourseCard({ course, onPress }: CourseCardProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const progress = Math.round((course.completedLessons / course.totalLessons) * 100);

  return (
    <Card onPress={onPress} variant="elevated">
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: course.color + '20' }]}>
          <Text style={styles.icon}>{course.icon}</Text>
        </View>
        <Badge label={course.level} size="sm" />
      </View>

      <Text style={[styles.title, isDark && styles.titleDark]}>{course.name}</Text>
      <Text style={[styles.description, isDark && styles.descriptionDark]} numberOfLines={2}>
        {course.description}
      </Text>

      <View style={styles.stats}>
        <Text style={[styles.statText, isDark && styles.statTextDark]}>
          {course.completedLessons}/{course.totalLessons} dars
        </Text>
      </View>

      <ProgressBar progress={progress} color={course.color} />
    </Card>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.md,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: 24,
  },
  title: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.xs,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  description: {
    fontSize: Typography.fontSize.sm,
    color: Colors.light.text.secondary,
    marginBottom: Spacing.md,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.sm,
  },
  descriptionDark: {
    color: Colors.dark.text.secondary,
  },
  stats: {
    marginBottom: Spacing.sm,
  },
  statText: {
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.medium,
    color: Colors.light.text.secondary,
  },
  statTextDark: {
    color: Colors.dark.text.secondary,
  },
});
