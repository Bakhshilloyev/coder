import React from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Card } from '../ui/Card';
import { Colors, Typography, Spacing } from '../../constants/theme';
import type { UserAchievement } from '../../services/storageService';

interface AchievementCardProps {
  achievement: UserAchievement;
}

export function AchievementCard({ achievement }: AchievementCardProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <Card variant="elevated">
      <View style={styles.content}>
        <Text style={[styles.icon, !achievement.unlocked && styles.iconLocked]}>
          {achievement.icon}
        </Text>
        <View style={styles.textContent}>
          <Text style={[styles.title, isDark && styles.titleDark, !achievement.unlocked && styles.titleLocked]}>
            {achievement.title}
          </Text>
          <Text style={[styles.description, isDark && styles.descriptionDark]}>
            {achievement.description}
          </Text>
          {achievement.unlocked && achievement.unlockedAt && (
            <Text style={[styles.date, isDark && styles.dateDark]}>
              {new Date(achievement.unlockedAt).toLocaleDateString('uz-UZ')}
            </Text>
          )}
        </View>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  icon: {
    fontSize: 48,
  },
  iconLocked: {
    opacity: 0.3,
  },
  textContent: {
    flex: 1,
    gap: Spacing.xs / 2,
  },
  title: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  titleLocked: {
    color: Colors.light.text.tertiary,
  },
  description: {
    fontSize: Typography.fontSize.sm,
    color: Colors.light.text.secondary,
  },
  descriptionDark: {
    color: Colors.dark.text.secondary,
  },
  date: {
    fontSize: Typography.fontSize.xs,
    color: Colors.primary.main,
    marginTop: Spacing.xs / 2,
  },
  dateDark: {
    color: Colors.primary.light,
  },
});
