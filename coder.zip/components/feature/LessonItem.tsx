import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import type { Lesson } from '../../constants/courses';

interface LessonItemProps {
  lesson: Lesson;
  onPress: () => void;
  isActive?: boolean;
}

export function LessonItem({ lesson, onPress, isActive = false }: LessonItemProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <TouchableOpacity
      style={[
        styles.container,
        isDark ? styles.containerDark : styles.containerLight,
        isActive && styles.active,
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.left}>
        <View
          style={[
            styles.iconContainer,
            lesson.completed && styles.iconCompleted,
            isActive && styles.iconActive,
          ]}
        >
          {lesson.completed ? (
            <Ionicons name="checkmark" size={16} color="#FFFFFF" />
          ) : (
            <Ionicons
              name="play"
              size={14}
              color={isActive ? '#FFFFFF' : Colors.light.text.tertiary}
            />
          )}
        </View>
        <View style={styles.content}>
          <Text style={[styles.title, isDark && styles.titleDark]} numberOfLines={1}>
            {lesson.title}
          </Text>
          <Text style={[styles.duration, isDark && styles.durationDark]}>
            {lesson.duration} daqiqa
          </Text>
        </View>
      </View>
      {lesson.quiz && (
        <View style={styles.quizBadge}>
          <Ionicons name="help-circle" size={16} color={Colors.primary.main} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  containerLight: {
    backgroundColor: Colors.light.surface,
    borderColor: Colors.light.border,
  },
  containerDark: {
    backgroundColor: Colors.dark.surface,
    borderColor: Colors.dark.border,
  },
  active: {
    borderColor: Colors.primary.main,
    borderWidth: 2,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: Spacing.md,
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.light.surfaceVariant,
  },
  iconCompleted: {
    backgroundColor: Colors.success,
  },
  iconActive: {
    backgroundColor: Colors.primary.main,
  },
  content: {
    flex: 1,
    gap: Spacing.xs / 2,
  },
  title: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.medium,
    color: Colors.light.text.primary,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  duration: {
    fontSize: Typography.fontSize.xs,
    color: Colors.light.text.tertiary,
  },
  durationDark: {
    color: Colors.dark.text.tertiary,
  },
  quizBadge: {
    marginLeft: Spacing.sm,
  },
});
