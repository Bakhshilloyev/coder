import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, useColorScheme, ScrollView } from 'react-native';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

interface CodeEditorProps {
  initialCode?: string;
  language?: string;
  onRun?: (code: string) => void;
  readOnly?: boolean;
}

export function CodeEditor({
  initialCode = '',
  language = 'python',
  onRun,
  readOnly = false,
}: CodeEditorProps) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [running, setRunning] = useState(false);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const handleRun = () => {
    setRunning(true);
    setTimeout(() => {
      // Simulate code execution
      if (code.includes('print')) {
        const match = code.match(/print\(['"](.*)['"]\)/);
        setOutput(match ? match[1] : 'Natija: Kod bajarildi ✅');
      } else {
        setOutput('Kod muvaffaqiyatli bajarildi ✅');
      }
      setRunning(false);
      onRun?.(code);
    }, 800);
  };

  return (
    <View style={styles.container}>
      <Card padding="sm">
        <View style={styles.header}>
          <Text style={[styles.language, isDark && styles.languageDark]}>{language}</Text>
          {!readOnly && (
            <Button title="▶ Ishga tushir" onPress={handleRun} loading={running} size="sm" />
          )}
        </View>

        <ScrollView style={styles.editorScroll} nestedScrollEnabled>
          <TextInput
            style={[
              styles.editor,
              isDark ? styles.editorDark : styles.editorLight,
              readOnly && styles.readOnly,
            ]}
            value={code}
            onChangeText={setCode}
            multiline
            editable={!readOnly}
            placeholder={readOnly ? '' : 'Kod yozing...'}
            placeholderTextColor={Colors.light.text.tertiary}
            autoCapitalize="none"
            autoCorrect={false}
            spellCheck={false}
          />
        </ScrollView>

        {output !== '' && (
          <View style={[styles.output, isDark ? styles.outputDark : styles.outputLight]}>
            <Text style={[styles.outputLabel, isDark && styles.outputLabelDark]}>Natija:</Text>
            <Text style={[styles.outputText, isDark && styles.outputTextDark]}>{output}</Text>
          </View>
        )}
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingTop: Spacing.sm,
  },
  language: {
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.light.text.secondary,
    textTransform: 'uppercase',
  },
  languageDark: {
    color: Colors.dark.text.secondary,
  },
  editorScroll: {
    maxHeight: 300,
  },
  editor: {
    fontFamily: Typography.fontFamily.mono,
    fontSize: Typography.fontSize.sm,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.sm,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    minHeight: 150,
    textAlignVertical: 'top',
  },
  editorLight: {
    backgroundColor: Colors.light.code.background,
    color: Colors.light.code.text,
  },
  editorDark: {
    backgroundColor: Colors.dark.code.background,
    color: Colors.dark.code.text,
  },
  readOnly: {
    opacity: 1,
  },
  output: {
    marginTop: Spacing.md,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  outputLight: {
    backgroundColor: Colors.light.surfaceVariant,
  },
  outputDark: {
    backgroundColor: Colors.dark.surfaceVariant,
  },
  outputLabel: {
    fontSize: Typography.fontSize.xs,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.light.text.secondary,
    marginBottom: Spacing.xs,
  },
  outputLabelDark: {
    color: Colors.dark.text.secondary,
  },
  outputText: {
    fontFamily: Typography.fontFamily.mono,
    fontSize: Typography.fontSize.sm,
    color: Colors.light.text.primary,
  },
  outputTextDark: {
    color: Colors.dark.text.primary,
  },
});
