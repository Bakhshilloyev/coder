import React, { useEffect } from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

interface ProgressBarProps {
  progress: number; // 0-100
  label?: string;
  showPercentage?: boolean;
  height?: number;
  color?: string;
}

export function ProgressBar({
  progress,
  label,
  showPercentage = true,
  height = 8,
  color,
}: ProgressBarProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const progressAnim = useSharedValue(0);

  useEffect(() => {
    progressAnim.value = withSpring(Math.min(Math.max(progress, 0), 100));
  }, [progress]);

  const animatedStyle = useAnimatedStyle(() => ({
    width: `${progressAnim.value}%`,
  }));

  return (
    <View style={styles.container}>
      {label && (
        <View style={styles.labelRow}>
          <Text style={[styles.label, isDark && styles.labelDark]}>{label}</Text>
          {showPercentage && (
            <Text style={[styles.percentage, isDark && styles.percentageDark]}>
              {Math.round(progress)}%
            </Text>
          )}
        </View>
      )}
      <View style={[styles.track, { height }, isDark ? styles.trackDark : styles.trackLight]}>
        <Animated.View
          style={[
            styles.fill,
            { height, backgroundColor: color || Colors.primary.main },
            animatedStyle,
          ]}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: Spacing.xs,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.medium,
    color: Colors.light.text.primary,
  },
  labelDark: {
    color: Colors.dark.text.primary,
  },
  percentage: {
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.primary.main,
  },
  percentageDark: {
    color: Colors.primary.light,
  },
  track: {
    width: '100%',
    borderRadius: BorderRadius.full,
    overflow: 'hidden',
  },
  trackLight: {
    backgroundColor: Colors.light.surfaceVariant,
  },
  trackDark: {
    backgroundColor: Colors.dark.surfaceVariant,
  },
  fill: {
    borderRadius: BorderRadius.full,
  },
});
