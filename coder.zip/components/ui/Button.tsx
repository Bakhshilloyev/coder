import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, useColorScheme } from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  fullWidth?: boolean;
}

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  icon,
  fullWidth = false,
}: ButtonProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <TouchableOpacity
      style={[
        styles.base,
        styles[variant],
        styles[size],
        isDark && styles[`${variant}Dark`],
        fullWidth && styles.fullWidth,
        (disabled || loading) && styles.disabled,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'primary' ? '#FFFFFF' : Colors.primary.main} />
      ) : (
        <>
          {icon}
          <Text style={[styles.text, styles[`${size}Text`], styles[`${variant}Text`], isDark && styles[`${variant}TextDark`]]}>
            {title}
          </Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: BorderRadius.md,
    gap: Spacing.sm,
  },
  fullWidth: {
    width: '100%',
  },
  disabled: {
    opacity: 0.5,
  },

  // Variants
  primary: {
    backgroundColor: Colors.primary.main,
  },
  primaryDark: {
    backgroundColor: Colors.primary.light,
  },
  secondary: {
    backgroundColor: Colors.secondary.main,
  },
  secondaryDark: {
    backgroundColor: Colors.secondary.dark,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: Colors.primary.main,
  },
  outlineDark: {
    borderColor: Colors.primary.light,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  ghostDark: {
    backgroundColor: 'transparent',
  },

  // Sizes
  sm: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  md: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  lg: {
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.xl,
  },

  // Text
  text: {
    fontWeight: Typography.fontWeight.semibold,
  },
  smText: {
    fontSize: Typography.fontSize.sm,
  },
  mdText: {
    fontSize: Typography.fontSize.base,
  },
  lgText: {
    fontSize: Typography.fontSize.lg,
  },
  primaryText: {
    color: '#FFFFFF',
  },
  primaryTextDark: {
    color: Colors.dark.background,
  },
  secondaryText: {
    color: '#FFFFFF',
  },
  secondaryTextDark: {
    color: '#FFFFFF',
  },
  outlineText: {
    color: Colors.primary.main,
  },
  outlineTextDark: {
    color: Colors.primary.light,
  },
  ghostText: {
    color: Colors.primary.main,
  },
  ghostTextDark: {
    color: Colors.primary.light,
  },
});
