import React from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

interface BadgeProps {
  label: string;
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info';
  size?: 'sm' | 'md';
}

export function Badge({ label, variant = 'default', size = 'md' }: BadgeProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <View style={[styles.badge, styles[variant], styles[size]]}>
      <Text style={[styles.text, styles[`${size}Text`], styles[`${variant}Text`]]}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    borderRadius: BorderRadius.sm,
    alignSelf: 'flex-start',
  },
  sm: {
    paddingVertical: Spacing.xs / 2,
    paddingHorizontal: Spacing.sm,
  },
  md: {
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
  },

  // Variants
  default: {
    backgroundColor: Colors.light.surfaceVariant,
  },
  success: {
    backgroundColor: Colors.success + '20',
  },
  warning: {
    backgroundColor: Colors.warning + '20',
  },
  error: {
    backgroundColor: Colors.error + '20',
  },
  info: {
    backgroundColor: Colors.info + '20',
  },

  // Text
  text: {
    fontWeight: Typography.fontWeight.medium,
  },
  smText: {
    fontSize: Typography.fontSize.xs,
  },
  mdText: {
    fontSize: Typography.fontSize.sm,
  },
  defaultText: {
    color: Colors.light.text.secondary,
  },
  successText: {
    color: Colors.success,
  },
  warningText: {
    color: Colors.warning,
  },
  errorText: {
    color: Colors.error,
  },
  infoText: {
    color: Colors.info,
  },
});
