import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, useColorScheme } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { LessonItem } from '../../components/feature/LessonItem';
import { CodeEditor } from '../../components/feature/CodeEditor';
import { QuizCard } from '../../components/feature/QuizCard';
import { Button } from '../../components/ui/Button';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { useCourse } from '../../hooks/useCourse';
import { Colors, Typography, Spacing } from '../../constants/theme';

export default function CourseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const { course, currentLesson, progress, completeLesson, selectLesson, loading } = useCourse(id as string);
  const [showQuiz, setShowQuiz] = useState(false);

  if (loading || !course || !currentLesson) {
    return (
      <View style={[styles.container, isDark && styles.containerDark]}>
        <Text style={[styles.loading, isDark && styles.loadingDark]}>Yuklanmoqda...</Text>
      </View>
    );
  }

  const handleCompleteLesson = async () => {
    if (currentLesson.quiz && !showQuiz) {
      setShowQuiz(true);
    } else {
      await completeLesson(currentLesson.id);
      setShowQuiz(false);
      
      // Move to next lesson
      const currentIndex = course.lessons.findIndex(l => l.id === currentLesson.id);
      if (currentIndex < course.lessons.length - 1) {
        await selectLesson(course.lessons[currentIndex + 1].id);
      }
    }
  };

  const handleQuizComplete = async (correct: boolean) => {
    if (correct) {
      await completeLesson(currentLesson.id);
      setShowQuiz(false);
      
      // Move to next lesson
      const currentIndex = course.lessons.findIndex(l => l.id === currentLesson.id);
      if (currentIndex < course.lessons.length - 1) {
        await selectLesson(course.lessons[currentIndex + 1].id);
      }
    } else {
      setShowQuiz(false);
    }
  };

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack.Screen
        options={{
          headerShown: true,
          title: course.name,
          headerBackTitle: 'Orqaga',
          headerStyle: {
            backgroundColor: isDark ? Colors.dark.surface : Colors.light.surface,
          },
          headerTintColor: isDark ? Colors.dark.text.primary : Colors.light.text.primary,
        }}
      />

      <View style={styles.content}>
        <View style={styles.leftPanel}>
          <View style={[styles.progressHeader, isDark && styles.progressHeaderDark]}>
            <Text style={[styles.progressTitle, isDark && styles.progressTitleDark]}>
              Darslar
            </Text>
            <ProgressBar progress={progress} showPercentage color={course.color} />
          </View>

          <ScrollView style={styles.lessonList} showsVerticalScrollIndicator={false}>
            {course.lessons.map(lesson => (
              <LessonItem
                key={lesson.id}
                lesson={lesson}
                onPress={() => {
                  selectLesson(lesson.id);
                  setShowQuiz(false);
                }}
                isActive={lesson.id === currentLesson.id}
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.rightPanel}>
          <ScrollView
            style={styles.lessonContent}
            contentContainerStyle={styles.lessonContentInner}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.lessonHeader}>
              <Text style={[styles.lessonTitle, isDark && styles.lessonTitleDark]}>
                {currentLesson.title}
              </Text>
              <Text style={[styles.lessonDescription, isDark && styles.lessonDescriptionDark]}>
                {currentLesson.description}
              </Text>
              <View style={styles.lessonMeta}>
                <View style={styles.metaItem}>
                  <Ionicons
                    name="time-outline"
                    size={16}
                    color={isDark ? Colors.dark.text.secondary : Colors.light.text.secondary}
                  />
                  <Text style={[styles.metaText, isDark && styles.metaTextDark]}>
                    {currentLesson.duration} daqiqa
                  </Text>
                </View>
                {currentLesson.quiz && (
                  <View style={styles.metaItem}>
                    <Ionicons
                      name="help-circle-outline"
                      size={16}
                      color={isDark ? Colors.dark.text.secondary : Colors.light.text.secondary}
                    />
                    <Text style={[styles.metaText, isDark && styles.metaTextDark]}>
                      Viktorina bor
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {!showQuiz && currentLesson.code && (
              <CodeEditor
                initialCode={currentLesson.code}
                language={course.language.toLowerCase()}
                readOnly={currentLesson.completed}
              />
            )}

            {showQuiz && currentLesson.quiz && (
              <QuizCard quiz={currentLesson.quiz} onComplete={handleQuizComplete} />
            )}

            <View style={styles.actionButtons}>
              {!currentLesson.completed && !showQuiz && (
                <Button
                  title={currentLesson.quiz ? 'Viktorinaga o\'tish' : 'Darsni tugatish'}
                  onPress={handleCompleteLesson}
                  fullWidth
                  icon={<Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />}
                />
              )}
              {currentLesson.completed && (
                <View style={styles.completedBadge}>
                  <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
                  <Text style={styles.completedText}>Dars tugallangan! 🎉</Text>
                </View>
              )}
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  containerDark: {
    backgroundColor: Colors.dark.background,
  },
  loading: {
    textAlign: 'center',
    marginTop: 100,
    fontSize: Typography.fontSize.lg,
    color: Colors.light.text.secondary,
  },
  loadingDark: {
    color: Colors.dark.text.secondary,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
  },
  leftPanel: {
    width: 280,
    borderRightWidth: 1,
    borderRightColor: Colors.light.border,
  },
  progressHeader: {
    padding: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.border,
    gap: Spacing.md,
  },
  progressHeaderDark: {
    borderBottomColor: Colors.dark.border,
  },
  progressTitle: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.light.text.primary,
  },
  progressTitleDark: {
    color: Colors.dark.text.primary,
  },
  lessonList: {
    flex: 1,
    padding: Spacing.sm,
  },
  rightPanel: {
    flex: 1,
  },
  lessonContent: {
    flex: 1,
  },
  lessonContentInner: {
    padding: Spacing.lg,
    gap: Spacing.lg,
  },
  lessonHeader: {
    gap: Spacing.sm,
  },
  lessonTitle: {
    fontSize: Typography.fontSize['2xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
  },
  lessonTitleDark: {
    color: Colors.dark.text.primary,
  },
  lessonDescription: {
    fontSize: Typography.fontSize.base,
    color: Colors.light.text.secondary,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
  },
  lessonDescriptionDark: {
    color: Colors.dark.text.secondary,
  },
  lessonMeta: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.sm,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metaText: {
    fontSize: Typography.fontSize.sm,
    color: Colors.light.text.secondary,
  },
  metaTextDark: {
    color: Colors.dark.text.secondary,
  },
  actionButtons: {
    marginTop: Spacing.md,
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    padding: Spacing.md,
    backgroundColor: Colors.success + '15',
    borderRadius: 12,
  },
  completedText: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.success,
  },
});
