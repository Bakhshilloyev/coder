import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, useColorScheme } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { CodeEditor } from '../../components/feature/CodeEditor';
import { Button } from '../../components/ui/Button';
import { Colors, Typography, Spacing } from '../../constants/theme';

const PRACTICE_CHALLENGES = [
  {
    id: '1',
    title: 'Hello World',
    description: 'Ekranga "Hello, World!" matnini chiqaring',
    language: 'python',
    starter: '# Matnni chiqaring\n',
    solution: 'print("Hello, World!")',
  },
  {
    id: '2',
    title: 'Ikki sonni qo\'shish',
    description: 'Ikki sonni qo\'shing va natijani chiqaring',
    language: 'python',
    starter: 'a = 5\nb = 3\n# Natijani hisoblang\n',
    solution: 'a = 5\nb = 3\nprint(a + b)',
  },
  {
    id: '3',
    title: 'Salom funksiyasi',
    description: 'Ismni qabul qilib, salomlashadigan funksiya yarating',
    language: 'javascript',
    starter: '// Funksiya yarating\n',
    solution: 'function salom(ism) {\n  console.log(`Salom, ${ism}!`);\n}\nsalom("Ali");',
  },
];

export default function PracticeScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const [currentIndex, setCurrentIndex] = useState(0);

  const challenge = PRACTICE_CHALLENGES[currentIndex];

  const handleNext = () => {
    if (currentIndex < PRACTICE_CHALLENGES.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + Spacing.md }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, isDark && styles.titleDark]}>Mashqlar</Text>
          <Text style={[styles.subtitle, isDark && styles.subtitleDark]}>
            Amaliyot orqali o'rganing
          </Text>
        </View>

        <View style={styles.progress}>
          <Text style={[styles.progressText, isDark && styles.progressTextDark]}>
            {currentIndex + 1} / {PRACTICE_CHALLENGES.length}
          </Text>
        </View>

        <View style={styles.challengeInfo}>
          <Text style={[styles.challengeTitle, isDark && styles.challengeTitleDark]}>
            {challenge.title}
          </Text>
          <Text style={[styles.challengeDescription, isDark && styles.challengeDescriptionDark]}>
            {challenge.description}
          </Text>
        </View>

        <CodeEditor initialCode={challenge.starter} language={challenge.language} />

        <View style={styles.navigation}>
          <Button
            title="← Oldingi"
            onPress={handlePrev}
            variant="outline"
            disabled={currentIndex === 0}
          />
          <Button
            title="Keyingi →"
            onPress={handleNext}
            disabled={currentIndex === PRACTICE_CHALLENGES.length - 1}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  containerDark: {
    backgroundColor: Colors.dark.background,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  header: {
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: Typography.fontSize['3xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.xs,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  subtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.light.text.secondary,
  },
  subtitleDark: {
    color: Colors.dark.text.secondary,
  },
  progress: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  progressText: {
    fontSize: Typography.fontSize.lg,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.primary.main,
  },
  progressTextDark: {
    color: Colors.primary.light,
  },
  challengeInfo: {
    marginBottom: Spacing.lg,
  },
  challengeTitle: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.xs,
  },
  challengeTitleDark: {
    color: Colors.dark.text.primary,
  },
  challengeDescription: {
    fontSize: Typography.fontSize.base,
    color: Colors.light.text.secondary,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
  },
  challengeDescriptionDark: {
    color: Colors.dark.text.secondary,
  },
  navigation: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.lg,
  },
});
