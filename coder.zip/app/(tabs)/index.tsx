import React from 'react';
import { View, Text, StyleSheet, ScrollView, useColorScheme } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { CourseCard } from '../../components/feature/CourseCard';
import { useProgress } from '../../hooks/useProgress';
import { Colors, Typography, Spacing } from '../../constants/theme';

export default function CoursesScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const { courses, stats, loading } = useProgress();

  if (loading) {
    return (
      <View style={[styles.container, isDark && styles.containerDark]}>
        <Text style={[styles.loading, isDark && styles.loadingDark]}>Yuklanmoqda...</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + Spacing.md }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, isDark && styles.titleDark]}>Coder</Text>
          <Text style={[styles.subtitle, isDark && styles.subtitleDark]}>
            Dasturlashni o'rganing 🚀
          </Text>
        </View>

        <View style={styles.statsRow}>
          <View style={[styles.statCard, isDark && styles.statCardDark]}>
            <Text style={[styles.statNumber, isDark && styles.statNumberDark]}>
              {stats.streak}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Kunlik seriya</Text>
          </View>
          <View style={[styles.statCard, isDark && styles.statCardDark]}>
            <Text style={[styles.statNumber, isDark && styles.statNumberDark]}>
              {stats.completedLessons}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Tugallangan</Text>
          </View>
          <View style={[styles.statCard, isDark && styles.statCardDark]}>
            <Text style={[styles.statNumber, isDark && styles.statNumberDark]}>
              {stats.totalMinutes}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Daqiqa</Text>
          </View>
        </View>

        <Text style={[styles.sectionTitle, isDark && styles.sectionTitleDark]}>
          Kurslar ({courses.length})
        </Text>

        <View style={styles.courseList}>
          {courses.map(course => (
            <CourseCard
              key={course.id}
              course={course}
              onPress={() => router.push(`/course/${course.id}`)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  containerDark: {
    backgroundColor: Colors.dark.background,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  loading: {
    flex: 1,
    textAlign: 'center',
    marginTop: 100,
    fontSize: Typography.fontSize.lg,
    color: Colors.light.text.secondary,
  },
  loadingDark: {
    color: Colors.dark.text.secondary,
  },
  header: {
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: Typography.fontSize['3xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.xs,
  },
  titleDark: {
    color: Colors.dark.text.primary,
  },
  subtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.light.text.secondary,
  },
  subtitleDark: {
    color: Colors.dark.text.secondary,
  },
  statsRow: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.light.surface,
    padding: Spacing.md,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  statCardDark: {
    backgroundColor: Colors.dark.surface,
    borderColor: Colors.dark.border,
  },
  statNumber: {
    fontSize: Typography.fontSize['2xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.primary.main,
    marginBottom: Spacing.xs / 2,
  },
  statNumberDark: {
    color: Colors.primary.light,
  },
  statLabel: {
    fontSize: Typography.fontSize.xs,
    color: Colors.light.text.secondary,
    textAlign: 'center',
  },
  statLabelDark: {
    color: Colors.dark.text.secondary,
  },
  sectionTitle: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.md,
  },
  sectionTitleDark: {
    color: Colors.dark.text.primary,
  },
  courseList: {
    gap: Spacing.md,
  },
});
