import React from 'react';
import { View, Text, StyleSheet, ScrollView, useColorScheme, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { AchievementCard } from '../../components/feature/AchievementCard';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { useProgress } from '../../hooks/useProgress';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const { profile, achievements, stats } = useProgress();

  const xpForNextLevel = 1000;
  const xpProgress = ((stats.xp % xpForNextLevel) / xpForNextLevel) * 100;

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + Spacing.md }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.profileHeader}>
          <View style={[styles.avatar, isDark && styles.avatarDark]}>
            <Text style={styles.avatarEmoji}>{profile?.avatar || '👤'}</Text>
          </View>
          <Text style={[styles.name, isDark && styles.nameDark]}>{profile?.name || 'O\'quvchi'}</Text>
          <View style={styles.levelBadge}>
            <Text style={styles.levelText}>Level {stats.level}</Text>
          </View>
        </View>

        <View style={[styles.xpCard, isDark && styles.xpCardDark]}>
          <Text style={[styles.xpTitle, isDark && styles.xpTitleDark]}>Tajriba</Text>
          <ProgressBar
            progress={xpProgress}
            label={`${stats.xp % xpForNextLevel} / ${xpForNextLevel} XP`}
            showPercentage={false}
          />
        </View>

        <View style={styles.statsGrid}>
          <View style={[styles.statBox, isDark && styles.statBoxDark]}>
            <Ionicons name="flame" size={32} color={Colors.warning} />
            <Text style={[styles.statValue, isDark && styles.statValueDark]}>{stats.streak}</Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Kunlik seriya</Text>
          </View>
          <View style={[styles.statBox, isDark && styles.statBoxDark]}>
            <Ionicons name="checkmark-circle" size={32} color={Colors.success} />
            <Text style={[styles.statValue, isDark && styles.statValueDark]}>
              {stats.completedLessons}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Darslar</Text>
          </View>
          <View style={[styles.statBox, isDark && styles.statBoxDark]}>
            <Ionicons name="time" size={32} color={Colors.primary.main} />
            <Text style={[styles.statValue, isDark && styles.statValueDark]}>
              {stats.totalMinutes}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Daqiqa</Text>
          </View>
          <View style={[styles.statBox, isDark && styles.statBoxDark]}>
            <Ionicons name="trophy" size={32} color="#FFD700" />
            <Text style={[styles.statValue, isDark && styles.statValueDark]}>
              {stats.unlockedAchievements}
            </Text>
            <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>Yutuqlar</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isDark && styles.sectionTitleDark]}>
            Yutuqlar ({stats.unlockedAchievements}/{achievements.length})
          </Text>
          <View style={styles.achievementList}>
            {achievements.map(achievement => (
              <AchievementCard key={achievement.id} achievement={achievement} />
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  containerDark: {
    backgroundColor: Colors.dark.background,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.light.surfaceVariant,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  avatarDark: {
    backgroundColor: Colors.dark.surfaceVariant,
  },
  avatarEmoji: {
    fontSize: 48,
  },
  name: {
    fontSize: Typography.fontSize['2xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.sm,
  },
  nameDark: {
    color: Colors.dark.text.primary,
  },
  levelBadge: {
    backgroundColor: Colors.primary.main,
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  levelText: {
    color: '#FFFFFF',
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.semibold,
  },
  xpCard: {
    backgroundColor: Colors.light.surface,
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  xpCardDark: {
    backgroundColor: Colors.dark.surface,
    borderColor: Colors.dark.border,
  },
  xpTitle: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.md,
  },
  xpTitleDark: {
    color: Colors.dark.text.primary,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  statBox: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: Colors.light.surface,
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  statBoxDark: {
    backgroundColor: Colors.dark.surface,
    borderColor: Colors.dark.border,
  },
  statValue: {
    fontSize: Typography.fontSize['2xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
  },
  statValueDark: {
    color: Colors.dark.text.primary,
  },
  statLabel: {
    fontSize: Typography.fontSize.xs,
    color: Colors.light.text.secondary,
    textAlign: 'center',
  },
  statLabelDark: {
    color: Colors.dark.text.secondary,
  },
  section: {
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.light.text.primary,
    marginBottom: Spacing.md,
  },
  sectionTitleDark: {
    color: Colors.dark.text.primary,
  },
  achievementList: {
    gap: Spacing.md,
  },
});
