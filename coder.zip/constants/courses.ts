/**
 * Course Data - 300+ Lessons Structure
 * Coder App - Learning Content
 */

export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: number; // minutes
  completed: boolean;
  code?: string;
  quiz?: Quiz;
}

export interface Quiz {
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Course {
  id: string;
  name: string;
  language: string;
  icon: string;
  color: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  totalLessons: number;
  completedLessons: number;
  description: string;
  lessons: Lesson[];
}

// Python Course (100 lessons)
const pythonLessons: Lesson[] = [
  {
    id: 'py-1',
    title: 'Python-ga kirish',
    description: 'Python nima va nima uchun uni o\'rganish kerak',
    duration: 5,
    completed: false,
    code: 'print("Salom, dunyo!")',
    quiz: {
      question: 'Qaysi operator matn chiqaradi?',
      options: ['show()', 'print()', 'display()', 'write()'],
      correctAnswer: 1,
    },
  },
  {
    id: 'py-2',
    title: 'O\'zgaruvchilar',
    description: 'O\'zgaruvchilarni e\'lon qilish va ishlatish',
    duration: 8,
    completed: false,
    code: 'ism = "Ali"\nyosh = 25\nprint(ism, yosh)',
    quiz: {
      question: 'O\'zgaruvchi qiymatini o\'zgartirish mumkinmi?',
      options: ['Ha', 'Yo\'q', 'Faqat raqamlar', 'Faqat matnlar'],
      correctAnswer: 0,
    },
  },
  {
    id: 'py-3',
    title: 'Ma\'lumot turlari',
    description: 'int, float, str, bool turlari',
    duration: 10,
    completed: false,
    code: 'raqam = 42\nfloat_son = 3.14\nmatn = "Python"\nrost = True',
  },
  {
    id: 'py-4',
    title: 'Matematik amallar',
    description: '+, -, *, /, //, %, ** operatorlari',
    duration: 7,
    completed: false,
    code: 'a = 10\nb = 3\nprint(a + b, a - b, a * b, a / b)',
  },
  {
    id: 'py-5',
    title: 'Shartli operatorlar',
    description: 'if, elif, else konstruksiyalari',
    duration: 12,
    completed: false,
    code: 'yosh = 18\nif yosh >= 18:\n    print("Kattasiz")\nelse:\n    print("Bolasiz")',
  },
];

// JavaScript Course (100 lessons)
const javascriptLessons: Lesson[] = [
  {
    id: 'js-1',
    title: 'JavaScript-ga kirish',
    description: 'JS nima va u qayerda ishlatiladi',
    duration: 5,
    completed: false,
    code: 'console.log("Hello, World!");',
    quiz: {
      question: 'Qaysi funksiya console-ga yozadi?',
      options: ['print()', 'console.log()', 'write()', 'show()'],
      correctAnswer: 1,
    },
  },
  {
    id: 'js-2',
    title: 'O\'zgaruvchilar: let, const, var',
    description: 'O\'zgaruvchilarni to\'g\'ri e\'lon qilish',
    duration: 8,
    completed: false,
    code: 'let name = "Ali";\nconst age = 25;\nvar city = "Toshkent";',
  },
  {
    id: 'js-3',
    title: 'Ma\'lumot turlari',
    description: 'String, Number, Boolean, Undefined, Null',
    duration: 10,
    completed: false,
    code: 'let str = "text";\nlet num = 42;\nlet bool = true;\nlet empty;',
  },
  {
    id: 'js-4',
    title: 'Funksiyalar',
    description: 'Function declaration va arrow functions',
    duration: 12,
    completed: false,
    code: 'function salom(ism) {\n  return `Salom, ${ism}!`;\n}\nconst yig\'indi = (a, b) => a + b;',
  },
  {
    id: 'js-5',
    title: 'Massivlar',
    description: 'Array yaratish va metodlari',
    duration: 15,
    completed: false,
    code: 'const sonlar = [1, 2, 3, 4, 5];\nsonlar.push(6);\nsonlar.map(x => x * 2);',
  },
];

// HTML/CSS Course (80 lessons)
const htmlCssLessons: Lesson[] = [
  {
    id: 'html-1',
    title: 'HTML asoslari',
    description: 'HTML nima va uning tuzilishi',
    duration: 5,
    completed: false,
    code: '<!DOCTYPE html>\n<html>\n<head>\n  <title>Birinchi sahifa</title>\n</head>\n<body>\n  <h1>Salom!</h1>\n</body>\n</html>',
  },
  {
    id: 'html-2',
    title: 'Teglар va elementlar',
    description: 'h1-h6, p, div, span, a, img',
    duration: 10,
    completed: false,
    code: '<h1>Sarlavha</h1>\n<p>Paragraf matni</p>\n<a href="/">Havola</a>',
  },
  {
    id: 'html-3',
    title: 'CSS bilan uslublash',
    description: 'Ranglar, shriftlar, o\'lchamlar',
    duration: 12,
    completed: false,
    code: '<style>\n  h1 {\n    color: blue;\n    font-size: 32px;\n  }\n</style>',
  },
  {
    id: 'html-4',
    title: 'Flexbox layout',
    description: 'Zamonaviy layout yaratish',
    duration: 15,
    completed: false,
    code: '.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}',
  },
  {
    id: 'html-5',
    title: 'Responsive dizayn',
    description: 'Media queries va mobile-first',
    duration: 18,
    completed: false,
    code: '@media (max-width: 768px) {\n  .container {\n    flex-direction: column;\n  }\n}',
  },
];

// Java Course (60 lessons)
const javaLessons: Lesson[] = [
  {
    id: 'java-1',
    title: 'Java-ga kirish',
    description: 'Java platformasi va JVM',
    duration: 5,
    completed: false,
    code: 'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello, World!");\n  }\n}',
  },
  {
    id: 'java-2',
    title: 'O\'zgaruvchilar va ma\'lumot turlari',
    description: 'int, double, String, boolean',
    duration: 10,
    completed: false,
    code: 'int age = 25;\nString name = "Ali";\nboolean isStudent = true;',
  },
  {
    id: 'java-3',
    title: 'Metodlar',
    description: 'Metodlar yaratish va chaqirish',
    duration: 12,
    completed: false,
    code: 'public static int sum(int a, int b) {\n  return a + b;\n}',
  },
  {
    id: 'java-4',
    title: 'Sinflar va obyektlar',
    description: 'OOP asoslari',
    duration: 15,
    completed: false,
    code: 'public class Person {\n  String name;\n  int age;\n  \n  public Person(String n, int a) {\n    name = n;\n    age = a;\n  }\n}',
  },
  {
    id: 'java-5',
    title: 'Massivlar',
    description: 'Array yaratish va ishlatish',
    duration: 12,
    completed: false,
    code: 'int[] numbers = {1, 2, 3, 4, 5};\nfor (int num : numbers) {\n  System.out.println(num);\n}',
  },
];

// C++ Course (60 lessons) 
const cppLessons: Lesson[] = [
  {
    id: 'cpp-1',
    title: 'C++ ga kirish',
    description: 'C++ tili va uning afzalliklari',
    duration: 5,
    completed: false,
    code: '#include <iostream>\nusing namespace std;\n\nint main() {\n  cout << "Hello World";\n  return 0;\n}',
  },
  {
    id: 'cpp-2',
    title: 'O\'zgaruvchilar',
    description: 'int, float, double, char, string',
    duration: 8,
    completed: false,
    code: 'int age = 25;\nfloat pi = 3.14;\nstring name = "Ali";',
  },
  {
    id: 'cpp-3',
    title: 'Funksiyalar',
    description: 'Funksiyalar yaratish va return',
    duration: 10,
    completed: false,
    code: 'int sum(int a, int b) {\n  return a + b;\n}\n\nint result = sum(5, 3);',
  },
  {
    id: 'cpp-4',
    title: 'Pointers',
    description: 'Ko\'rsatkichlar bilan ishlash',
    duration: 15,
    completed: false,
    code: 'int x = 10;\nint* ptr = &x;\ncout << *ptr;',
  },
  {
    id: 'cpp-5',
    title: 'Sinflar',
    description: 'OOP va sinflar',
    duration: 18,
    completed: false,
    code: 'class Rectangle {\npublic:\n  int width, height;\n  int area() { return width * height; }\n};',
  },
];

// Generate more lessons programmatically to reach 300+
function generateMoreLessons(base: Lesson[], language: string, startId: number, count: number): Lesson[] {
  const topics = [
    'Loops', 'Functions', 'Arrays', 'Objects', 'Classes', 'Inheritance', 
    'Polymorphism', 'Error Handling', 'File I/O', 'Debugging', 'Testing',
    'Algorithms', 'Data Structures', 'Recursion', 'Sorting', 'Searching',
    'APIs', 'Databases', 'Web Development', 'Mobile Apps'
  ];
  
  const moreLessons: Lesson[] = [];
  for (let i = 0; i < count; i++) {
    const topic = topics[i % topics.length];
    moreLessons.push({
      id: `${language}-${startId + i}`,
      title: `${topic} - ${i + 1}-qism`,
      description: `${topic} haqida batafsil ma'lumot`,
      duration: 10 + (i % 10),
      completed: false,
      code: `// ${topic} code example\n// Dars kodi shu yerda`,
    });
  }
  return moreLessons;
}

export const COURSES: Course[] = [
  {
    id: 'python',
    name: 'Python',
    language: 'Python',
    icon: '🐍',
    color: '#3776AB',
    level: 'Beginner',
    totalLessons: 100,
    completedLessons: 0,
    description: 'Zamonaviy dasturlash tili - AI va data science uchun',
    lessons: [...pythonLessons, ...generateMoreLessons(pythonLessons, 'py', 6, 95)],
  },
  {
    id: 'javascript',
    name: 'JavaScript',
    language: 'JavaScript',
    icon: '⚡',
    color: '#F7DF1E',
    level: 'Beginner',
    totalLessons: 100,
    completedLessons: 0,
    description: 'Web dasturlash asosi - frontend va backend',
    lessons: [...javascriptLessons, ...generateMoreLessons(javascriptLessons, 'js', 6, 95)],
  },
  {
    id: 'html-css',
    name: 'HTML & CSS',
    language: 'Web',
    icon: '🎨',
    color: '#E34F26',
    level: 'Beginner',
    totalLessons: 80,
    completedLessons: 0,
    description: 'Veb-sahifalar yaratish - dizayn va struktura',
    lessons: [...htmlCssLessons, ...generateMoreLessons(htmlCssLessons, 'html', 6, 75)],
  },
  {
    id: 'java',
    name: 'Java',
    language: 'Java',
    icon: '☕',
    color: '#007396',
    level: 'Intermediate',
    totalLessons: 60,
    completedLessons: 0,
    description: 'Korporativ dasturlash - Android va enterprise',
    lessons: [...javaLessons, ...generateMoreLessons(javaLessons, 'java', 6, 55)],
  },
  {
    id: 'cpp',
    name: 'C++',
    language: 'C++',
    icon: '⚙️',
    color: '#00599C',
    level: 'Advanced',
    totalLessons: 60,
    completedLessons: 0,
    description: 'Tezkor dasturlash - o\'yinlar va tizim dasturlari',
    lessons: [...cppLessons, ...generateMoreLessons(cppLessons, 'cpp', 6, 55)],
  },
];

export const ACHIEVEMENTS = [
  { id: 'first-lesson', title: 'Birinchi qadam', description: 'Birinchi darsni tugatdingiz', icon: '🎯', unlocked: false },
  { id: 'week-streak', title: '7 kunlik seriya', description: '7 kun ketma-ket o\'rgandingiz', icon: '🔥', unlocked: false },
  { id: 'course-complete', title: 'Kurs mutaxassisi', description: 'Birinchi kursni tamomladingiz', icon: '🏆', unlocked: false },
  { id: 'quiz-master', title: 'Quiz ustasi', description: '50 ta viktorinadan o\'tdingiz', icon: '🧠', unlocked: false },
  { id: 'code-warrior', title: 'Kod jangchisi', description: '100 ta kod mashqini bajardingiz', icon: '⚔️', unlocked: false },
  { id: 'speed-learner', title: 'Tez o\'quvchi', description: '1 kunda 10 dars tugatdingiz', icon: '⚡', unlocked: false },
];
