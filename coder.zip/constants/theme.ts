/**
 * Design System - Theme Configuration
 * Coder App - Code Learning Platform
 */

export const Colors = {
  // Primary Brand Colors
  primary: {
    main: '#6C63FF',
    light: '#8B84FF',
    dark: '#5449E0',
    gradient: ['#6C63FF', '#4ECDC4'],
  },
  
  // Secondary Colors
  secondary: {
    main: '#4ECDC4',
    light: '#7DE0D8',
    dark: '#3BB5AD',
  },
  
  // Semantic Colors
  success: '#2ECC71',
  warning: '#F39C12',
  error: '#E74C3C',
  info: '#3498DB',
  
  // Language Colors (for course badges)
  language: {
    python: '#3776AB',
    javascript: '#F7DF1E',
    html: '#E34F26',
    css: '#1572B6',
    java: '#007396',
    cpp: '#00599C',
  },
  
  // Light Mode
  light: {
    background: '#FFFFFF',
    surface: '#F8F9FA',
    surfaceVariant: '#F1F3F5',
    border: '#E9ECEF',
    text: {
      primary: '#212529',
      secondary: '#6C757D',
      tertiary: '#ADB5BD',
      inverse: '#FFFFFF',
    },
    code: {
      background: '#2D2D2D',
      text: '#F8F8F2',
      keyword: '#FF79C6',
      string: '#50FA7B',
      comment: '#6272A4',
    },
  },
  
  // Dark Mode
  dark: {
    background: '#0D1117',
    surface: '#161B22',
    surfaceVariant: '#21262D',
    border: '#30363D',
    text: {
      primary: '#E6EDF3',
      secondary: '#8B949E',
      tertiary: '#6E7681',
      inverse: '#0D1117',
    },
    code: {
      background: '#0D1117',
      text: '#E6EDF3',
      keyword: '#FF7B72',
      string: '#A5D6FF',
      comment: '#8B949E',
    },
  },
};

export const Typography = {
  // Font Families
  fontFamily: {
    primary: 'System',
    mono: 'Courier',
  },
  
  // Font Sizes
  fontSize: {
    xs: 12,
    sm: 14,
    base: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 30,
    '4xl': 36,
  },
  
  // Font Weights
  fontWeight: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
  
  // Line Heights
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  '2xl': 48,
  '3xl': 64,
};

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const Shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 5,
  },
};

export const Animation = {
  duration: {
    fast: 150,
    normal: 250,
    slow: 350,
  },
  easing: {
    ease: 'ease-in-out',
    linear: 'linear',
  },
};
