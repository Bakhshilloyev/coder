/**
 * Local Storage Service
 * Manages user progress, courses, and achievements
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Course, COURSES, ACHIEVEMENTS } from '../constants/courses';

const KEYS = {
  USER_PROFILE: 'user_profile',
  COURSES: 'courses',
  ACHIEVEMENTS: 'achievements',
  STREAK: 'streak',
  LAST_ACTIVE: 'last_active',
};

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  level: number;
  xp: number;
  streak: number;
  totalLessons: number;
  totalMinutes: number;
}

export interface UserAchievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

// Initialize default data
export async function initializeData(): Promise<void> {
  try {
    const existingCourses = await AsyncStorage.getItem(KEYS.COURSES);
    if (!existingCourses) {
      await AsyncStorage.setItem(KEYS.COURSES, JSON.stringify(COURSES));
    }

    const existingProfile = await AsyncStorage.getItem(KEYS.USER_PROFILE);
    if (!existingProfile) {
      const defaultProfile: UserProfile = {
        name: 'O\'quvchi',
        email: '',
        avatar: '👤',
        level: 1,
        xp: 0,
        streak: 0,
        totalLessons: 0,
        totalMinutes: 0,
      };
      await AsyncStorage.setItem(KEYS.USER_PROFILE, JSON.stringify(defaultProfile));
    }

    const existingAchievements = await AsyncStorage.getItem(KEYS.ACHIEVEMENTS);
    if (!existingAchievements) {
      await AsyncStorage.setItem(KEYS.ACHIEVEMENTS, JSON.stringify(ACHIEVEMENTS));
    }
  } catch (error) {
    console.error('Failed to initialize data:', error);
  }
}

// User Profile
export async function getUserProfile(): Promise<UserProfile | null> {
  try {
    const data = await AsyncStorage.getItem(KEYS.USER_PROFILE);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Failed to get user profile:', error);
    return null;
  }
}

export async function updateUserProfile(profile: Partial<UserProfile>): Promise<void> {
  try {
    const current = await getUserProfile();
    if (current) {
      await AsyncStorage.setItem(KEYS.USER_PROFILE, JSON.stringify({ ...current, ...profile }));
    }
  } catch (error) {
    console.error('Failed to update user profile:', error);
  }
}

// Courses
export async function getCourses(): Promise<Course[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.COURSES);
    return data ? JSON.parse(data) : COURSES;
  } catch (error) {
    console.error('Failed to get courses:', error);
    return COURSES;
  }
}

export async function updateCourse(courseId: string, updates: Partial<Course>): Promise<void> {
  try {
    const courses = await getCourses();
    const updatedCourses = courses.map(course =>
      course.id === courseId ? { ...course, ...updates } : course
    );
    await AsyncStorage.setItem(KEYS.COURSES, JSON.stringify(updatedCourses));
  } catch (error) {
    console.error('Failed to update course:', error);
  }
}

export async function completeLesson(courseId: string, lessonId: string): Promise<void> {
  try {
    const courses = await getCourses();
    const updatedCourses = courses.map(course => {
      if (course.id === courseId) {
        const updatedLessons = course.lessons.map(lesson =>
          lesson.id === lessonId ? { ...lesson, completed: true } : lesson
        );
        const completedCount = updatedLessons.filter(l => l.completed).length;
        return {
          ...course,
          lessons: updatedLessons,
          completedLessons: completedCount,
        };
      }
      return course;
    });
    await AsyncStorage.setItem(KEYS.COURSES, JSON.stringify(updatedCourses));

    // Update user stats
    const profile = await getUserProfile();
    if (profile) {
      const lesson = courses.find(c => c.id === courseId)?.lessons.find(l => l.id === lessonId);
      await updateUserProfile({
        totalLessons: profile.totalLessons + 1,
        totalMinutes: profile.totalMinutes + (lesson?.duration || 0),
        xp: profile.xp + 50,
      });
    }

    // Check achievements
    await checkAchievements();
  } catch (error) {
    console.error('Failed to complete lesson:', error);
  }
}

// Achievements
export async function getAchievements(): Promise<UserAchievement[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.ACHIEVEMENTS);
    return data ? JSON.parse(data) : ACHIEVEMENTS;
  } catch (error) {
    console.error('Failed to get achievements:', error);
    return ACHIEVEMENTS;
  }
}

export async function unlockAchievement(achievementId: string): Promise<void> {
  try {
    const achievements = await getAchievements();
    const updated = achievements.map(ach =>
      ach.id === achievementId && !ach.unlocked
        ? { ...ach, unlocked: true, unlockedAt: new Date().toISOString() }
        : ach
    );
    await AsyncStorage.setItem(KEYS.ACHIEVEMENTS, JSON.stringify(updated));
  } catch (error) {
    console.error('Failed to unlock achievement:', error);
  }
}

async function checkAchievements(): Promise<void> {
  const profile = await getUserProfile();
  if (!profile) return;

  // First lesson
  if (profile.totalLessons === 1) {
    await unlockAchievement('first-lesson');
  }

  // 7-day streak
  if (profile.streak >= 7) {
    await unlockAchievement('week-streak');
  }

  // Course complete
  const courses = await getCourses();
  const hasCompletedCourse = courses.some(c => c.completedLessons === c.totalLessons);
  if (hasCompletedCourse) {
    await unlockAchievement('course-complete');
  }
}

// Streak management
export async function updateStreak(): Promise<void> {
  try {
    const lastActive = await AsyncStorage.getItem(KEYS.LAST_ACTIVE);
    const today = new Date().toDateString();

    if (lastActive !== today) {
      const profile = await getUserProfile();
      if (profile) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const isConsecutive = lastActive === yesterday.toDateString();

        await updateUserProfile({
          streak: isConsecutive ? profile.streak + 1 : 1,
        });
      }
      await AsyncStorage.setItem(KEYS.LAST_ACTIVE, today);
    }
  } catch (error) {
    console.error('Failed to update streak:', error);
  }
}

// Clear all data (for testing)
export async function clearAllData(): Promise<void> {
  try {
    await AsyncStorage.multiRemove([
      KEYS.USER_PROFILE,
      KEYS.COURSES,
      KEYS.ACHIEVEMENTS,
      KEYS.STREAK,
      KEYS.LAST_ACTIVE,
    ]);
    await initializeData();
  } catch (error) {
    console.error('Failed to clear data:', error);
  }
}
